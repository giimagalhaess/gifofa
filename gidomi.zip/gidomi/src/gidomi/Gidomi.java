/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gidomi;

import javax.swing.JOptionPane;

/**
 *
 * @author giovana.amagalhaes
 */
public class Gidomi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       // JOptionPane.showMessageDialog(null,"gi e do miguel");
        //JOptionPane.showMessageDialog(null,"eu amo ele");
        JOptionPane.showInputDialog(null,"oie fofinho");
         JOptionPane.showInputDialog(null,"qual seu nome");
         JOptionPane.showConfirmDialog(null,"voce fala russo");
        
    }
    
}
