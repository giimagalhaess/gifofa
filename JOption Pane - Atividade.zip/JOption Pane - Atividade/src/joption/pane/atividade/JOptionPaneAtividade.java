/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package joption.pane.atividade;

import javax.swing.JOptionPane;

/**
 *
 * @author giovana.amagalhaes
 */
public class JOptionPaneAtividade {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //String cpf= JOptionPane.showInputDialog(null,"digite seu Cpf");
       // String nome= JOptionPane.showInputDialog(null,"digite o nome");
       // JOptionPane.showMessageDialog(null,"Seu cpf e" + cpf +"seu nome" + nome);
       
        //for (int i = 1; i < 8; i++) {
           // JOptionPane.showMessageDialog(null,"repita");
       
     int opcao = JOptionPane.showConfirmDialog(null,"esta chovendo");   
     
     if (opcao == 0) {
         JOptionPane.showConfirmDialog(null,"Muito");
    }
     
     else if(opcao == 1) {
         JOptionPane.showMessageDialog(null,"Parou");
} 
     
     else if(opcao == 2) {  
         JOptionPane.showMessageDialog(null,"Cancelar");
     }
     
     else{
         JOptionPane.showMessageDialog(null,"Fechado");
     }
     
    }
    
}
         
         
      